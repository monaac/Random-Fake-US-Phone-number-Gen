document.getElementById('generate-button').addEventListener('click', function() {
    const phoneNumbers = generatePhoneNumbers(50000);
    const phoneNumbersContainer = document.getElementById('phone-numbers');
    phoneNumbersContainer.innerHTML = phoneNumbers.join('<br>');
});

function generatePhoneNumbers(count) {
    const phoneNumbers = [];
    for (let i = 0; i < count; i++) {
        phoneNumbers.push(generatePhoneNumber());
    }
    return phoneNumbers;
}

function generatePhoneNumber() {
    const areaCode = Math.floor(Math.random() * 900) + 100;
    const exchangeCode = Math.floor(Math.random() * 900) + 100;
    const subscriberNumber = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `(${areaCode}) ${exchangeCode}-${subscriberNumber}`;
}

document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for contacting us!');
    this.reset();
});
